'''
Created on Jan 25, 2013
@author: vandana
Important utilities for processing tweets
1. Language detection for tweets, based on the language supported by twitter
'''
import httplib2
import cjson
from langdetect import LangDetect

class LangDetectTwitter:
  def __init__(self):
    http = httplib2.Http()
    langurl = "https://api.twitter.com/1/help/languages.json"
    hdr, content = http.request(langurl, 'GET')
    if hdr.status == "200":
      content = cjson.decode(content)
      supported_langs = [x["code"] for x in content]
      self.ld = LangDetect(supported_langs)
    else:
      self.ld = LangDetect()

  def detect(self, texts):
    result = []
    for text in texts:
      result.append(self.ld.detect(text))
    return result