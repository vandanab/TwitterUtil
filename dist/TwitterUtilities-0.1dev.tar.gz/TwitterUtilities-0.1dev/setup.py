'''
Created on Jan 25, 2013
@author: vandana
'''
from distutils.core import setup

setup(
    name='TwitterUtilities',
    version='0.1dev',
    packages=['src',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)   
